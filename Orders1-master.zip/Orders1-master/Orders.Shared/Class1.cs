﻿namespace Orders.Shared
{
    public class Class1
    {

    }
}
